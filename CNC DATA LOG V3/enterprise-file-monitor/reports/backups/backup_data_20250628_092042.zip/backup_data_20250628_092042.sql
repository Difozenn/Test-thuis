-- Events Table
INSERT INTO event (timestamp, file_path, category_id, matched_keyword, computer_name, user_id, event_type, file_size) VALUES ('2025-06-26 21:11:18.667071', 'C:\TwinCAT\CNC\Field1.nc', 6, 'Content: _REP (Line 87: N780 ; --- 0526_a\OW_09Rug_REP_L.HOP ---)', 'DESKTOP-9PNEF5Q', 2, 'changed', 7225);

-- Categories Table
INSERT INTO category (name, keywords, file_patterns, color) VALUES ('Allerlei', '[]', '[]', '#6c757d');
INSERT INTO category (name, keywords, file_patterns, color) VALUES ('Reparatie', '["_REP", "_REP_"]', '[]', '#ff0000');
